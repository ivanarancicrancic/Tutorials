package mk.hotelreview.hotelr.hotelrapi.vuforia;

public interface IPostNewTargetStatusListener {
    void onStatusSuccess(String targetId);
}