package mk.hotelreview.hotelr.hotelrapi.controller;

import mk.hotelreview.hotelr.hotelrapi.entity.user.User;
import mk.hotelreview.hotelr.hotelrapi.model.request.EditAccountModel;
import mk.hotelreview.hotelr.hotelrapi.model.response.AccountModel;
import mk.hotelreview.hotelr.hotelrapi.model.response.UserModel;
import mk.hotelreview.hotelr.hotelrapi.security.AuthenticationFacade;
import mk.hotelreview.hotelr.hotelrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import mk.hotelreview.hotelr.hotelrapi.service.UserService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class UserController {

    private final AuthenticationFacade authenticationFacade;
    private final UserService userService;

    public UserController(AuthenticationFacade authenticationFacade, UserService userService) {
        this.authenticationFacade = authenticationFacade;
        this.userService = userService;
    }

    @RequestMapping(value = "/user", method = RequestMethod.GET)
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.USER_GET)
    public UserModel getUser() {
        return new UserModel(authenticationFacade.getAuthenticatedUser());
    }

    @RequestMapping(value = "/account", method = RequestMethod.GET)
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.USER_GET)
    public AccountModel getAccount() {
        return new AccountModel(authenticationFacade.getAuthenticatedUser());
    }

    @RequestMapping(value = "/account", method = RequestMethod.POST)
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.USER_GET)
    public AccountModel editAccount(@RequestBody EditAccountModel model) {
        User user = authenticationFacade.getAuthenticatedUser();
        user = userService.edit(user, model);
        return new AccountModel(user);
    }

}
