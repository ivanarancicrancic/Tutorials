package mk.hotelreview.hotelr.hotelrapi.security;

public final class SecurityConstants {
    public static final String SECRET = "XZxRYB(_N{B<YTg0HrAZ";
    public static final long EXPIRATION_TIME = 864_000_000; // 10 days
    public static final String TOKEN_PREFIX = "Bearer ";
    public static final String HEADER_STRING = "Authorization";

    public static final int RESETTED_PASSSWORD_LENGTH = 8;
    public static final int RESETTED_PASSSWORD_EXPIRE_DAYS = 90;
    public static final int INITIAL_PASSSWORD_EXPIRE_DAYS = 14;
    public static final int PASSWORD_RESET_TOKEN_LENGTH = 10;
    public static final int PASSWORD_RESET_TOKEN_EXPIRE_DAYS = 1;

    private SecurityConstants() {
        // NO-OP utility class
    }
}