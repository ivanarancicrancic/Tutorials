package mk.hotelreview.hotelr.hotelrapi.model.response;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;
import mk.hotelreview.hotelr.hotelrapi.entity.review.HotelReview;

public class HotelReviewModel {

    private long id;
    private String code;
    private HotelOverviewModel hotel;
    private UserModel user;
    private int numberLikes;
    private String comment;

    private HotelOverviewModel hotelToModel(Hotel hotel) {
            return new HotelOverviewModel(hotel);
    }


    public HotelReviewModel(HotelReview hotelReview) {
        this.id = hotelReview.getId();
        this.code = hotelReview.getCode();
        this.hotel = hotelToModel(hotelReview.getHotel());
        this.user = new UserModel(hotelReview.getUser());
        this.numberLikes = hotelReview.getLikesNumber();
        this.comment = hotelReview.getComment();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public HotelOverviewModel getHotel() {
        return hotel;
    }

    public void setHotel(HotelOverviewModel hotel) {
        this.hotel = hotel;
    }

    public UserModel getUser() {
        return user;
    }

    public void setUser(UserModel user) {
        this.user = user;
    }

    public int getNumberLikes() {
        return numberLikes;
    }

    public void setNumberLikes(int numberLikes) {
        this.numberLikes = numberLikes;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
