package mk.hotelreview.hotelr.hotelrapi.security;

public final class BuiltInRights {

    public static final String HOTEL_CREATE = "HOTEL_CREATE";
    public static final String HOTEL_LIST = "HOTEL_LIST";
    public static final String HOTEL_EDIT = "HOTEL_EDIT";
    public static final String HOTEL_GET = "HOTEL_GET";
    public static final String CONTENT_CREATE = "CONTENT_CREATE";
    public static final String CONTENT_EDIT = "CONTENT_EDIT";
    public static final String CONTENT_DELETE = "CONTENT_DELETE";
    public static final String IMAGE_DELETE = "IMAGE_DELETE";
    public static final String IMAGE_CREATE = "IMAGE_CREATE";
    public static final String REVIEWS_LIST = "REVIEWS_LIST";
    public static final String REVIEWS_LIST_FOR_HOTEL = "REVIEWS_LIST_FOR_HOTEL";
    public static final String REVIEW_LIKE = "REVIEW_LIKE";
    public static final String TRACKER_CREATE = "TRACKER_CREATE";
    public static final String TRACKER_EDIT = "TRACKER_EDIT";
    public static final String TRACKER_DELETE = "TRACKER_DELETE";
    public static final String USER_GET = "USER_GET";
    public static final String ADMIN_RIGHT = "ADMIN_RIGHT";

    private BuiltInRights() {
        // NO-OP utility class
    }

}
