package mk.hotelreview.hotelr.hotelrapi.service;

import mk.hotelreview.hotelr.hotelrapi.entity.content.Content;
import mk.hotelreview.hotelr.hotelrapi.entity.content.SlideshowContent;
import mk.hotelreview.hotelr.hotelrapi.entity.content.SlideshowImage;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;
import mk.hotelreview.hotelr.hotelrapi.model.request.CreateSlideshowContentModel;
import mk.hotelreview.hotelr.hotelrapi.model.request.CreateSlideshowImageModel;
import mk.hotelreview.hotelr.hotelrapi.model.request.EditSlideshowContentModel;
import mk.hotelreview.hotelr.hotelrapi.repository.ContentRepository;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class SlideshowContentService {

    private final ContentRepository contentRepository;
    private final SlideshowImageService slideshowImageService;

    public SlideshowContentService(ContentRepository contentRepository, SlideshowImageService slideshowImageService) {
        this.contentRepository = contentRepository;
        this.slideshowImageService = slideshowImageService;
    }

    public SlideshowContent create(Hotel hotel, @Valid CreateSlideshowContentModel model) {
        SlideshowContent content = new SlideshowContent();
//        content.setHotel(hotel);
        content.setName(model.getName());
        content.setPositionX(model.getPositionX());
        content.setPositionY(model.getRotationY());
        content.setPositionZ(model.getPositionZ());
        content.setRotationX(model.getRotationX());
        content.setRotationY(model.getRotationY());
        content.setRotationZ(model.getRotationZ());
        content.setScaleX(model.getScaleX());
        content.setScaleY(model.getScaleY());
        content.setScaleZ(model.getScaleZ());
        content.setExtendedTracking(model.isExtendedTracking());
        content.setRenderOnTrackingLost(model.isRenderOnTrackingLost());

        content.setType( SlideshowContent.Type.valueOf(model.getSubType()) );

        List<SlideshowImage> images = createImages(content, model.getImages());
        content.setImages(images);

        Optional<Content> contentWithHeighestWeight = contentRepository.findFirstByHotelOrderByWeightDesc(hotel);
        if (contentWithHeighestWeight.isPresent()) {
            content.setWeight(contentWithHeighestWeight.get().getWeight() + 1);
        } else {
            content.setWeight(1);
        }
        return contentRepository.save(content);
    }

    public SlideshowContent edit(SlideshowContent content, @Valid EditSlideshowContentModel model) {
        // content.setName(model.getName());
        content.setPositionX(model.getPositionX());
        content.setPositionY(model.getPositionY());
        content.setPositionZ(model.getPositionZ());
        content.setRotationX(model.getRotationX());
        content.setRotationY(model.getRotationY());
        content.setRotationZ(model.getRotationZ());
        content.setScaleX(model.getScaleX());
        content.setScaleY(model.getScaleY());
        content.setScaleZ(model.getScaleZ());

        slideshowImageService.delete(content.getImages());
        List<SlideshowImage> images = createImages(content, model.getImages());
        content.setImages(images);

        content.setExtendedTracking(model.isExtendedTracking());
        content.setRenderOnTrackingLost(model.isRenderOnTrackingLost());
        return contentRepository.save(content);
    }

    public List<SlideshowImage> createImages(SlideshowContent content, List<CreateSlideshowImageModel> images2) {
        List<SlideshowImage> images = new ArrayList<>();
        for(int i = 0; i < images2.size(); ++i) {
            String url = images2.get(i).getUrl();
            SlideshowImage slideshowImage = new SlideshowImage();
            slideshowImage.setUrl(url);
            slideshowImage.setWeight(i+1);
            slideshowImage.setSlideshow(content);
            images.add(slideshowImage);
        }
        return images;
    }

}