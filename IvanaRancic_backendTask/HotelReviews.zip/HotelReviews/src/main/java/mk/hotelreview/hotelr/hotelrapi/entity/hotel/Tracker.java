package mk.hotelreview.hotelr.hotelrapi.entity.hotel;

import javax.persistence.*;

@Entity
@Table(name = "trackers")
public class Tracker {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "key_tracker")
    private long id;

    @ManyToOne(fetch = javax.persistence.FetchType.EAGER)
    @JoinColumn(name = "fk_hotel", nullable = false)
    private Hotel hotel;

    @Column(name = "vuforia_id", nullable = false)
    private String vuforiaId;

    @Column(name = "url", nullable = false)
    private String url;

    @Column(name = "trackings")
    private long trackings = 0;

    // getter & setter
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Hotel getHotel() {
        return hotel;
    }

    public void setHotel(Hotel hotel) {
        this.hotel = hotel;
    }

    public String getVuforiaId() {
        return vuforiaId;
    }

    public void setVuforiaId(String vuforiaId) {
        this.vuforiaId = vuforiaId;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public long getTrackings() {
        return trackings;
    }

    public void setTrackings(long trackings) {
        this.trackings = trackings;
    }
}
