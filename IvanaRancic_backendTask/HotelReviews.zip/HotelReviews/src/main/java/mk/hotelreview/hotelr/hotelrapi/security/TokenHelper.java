package mk.hotelreview.hotelr.hotelrapi.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Component;

import java.util.Date;

import static mk.hotelreview.hotelr.hotelrapi.security.SecurityConstants.SECRET;
import static mk.hotelreview.hotelr.hotelrapi.security.SecurityConstants.TOKEN_PREFIX;

@Component
public final class TokenHelper {

    public static String createToken(String username, Date expirationTime) {
        System.out.println("Token created!");

        return TOKEN_PREFIX + Jwts.builder()
                .setSubject(username)
                .setExpiration(expirationTime)
                .signWith(SignatureAlgorithm.HS512, SECRET.getBytes())
                .compact();

    }

    public static String userFromToken(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET.getBytes())
                .parseClaimsJws(token.replace(TOKEN_PREFIX, ""))
                .getBody()
                .getSubject();
    }

    private TokenHelper() {
        // NO-OP utility class
    }

}
