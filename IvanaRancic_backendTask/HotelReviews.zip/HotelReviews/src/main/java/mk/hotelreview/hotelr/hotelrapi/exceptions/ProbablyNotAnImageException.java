package mk.hotelreview.hotelr.hotelrapi.exceptions;

public class ProbablyNotAnImageException extends Throwable {
}
