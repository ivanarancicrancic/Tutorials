package mk.hotelreview.hotelr.hotelrapi.model.response;

import mk.hotelreview.hotelr.hotelrapi.entity.content.Content;
import mk.hotelreview.hotelr.hotelrapi.entity.content.SlideshowContent;
import mk.hotelreview.hotelr.hotelrapi.entity.content.SlideshowImage;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Tracker;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MobileTrackerResponse {

    private String targetID;
    private long hotelID;

    private String phone = "under construction";
    private String email = "under construction";
    private String web = "under construction";
    private String name = "under construction";
    private String address2 = "under construction";
    private String city = "under construction";

    private boolean photo = false;

    private long smoothCamFramesPosition = 3;
    private long smoothCamFramesRotation = 4;

    private List<SlideshowResponse> slideshows = new ArrayList<>();

    public MobileTrackerResponse() {

    }

    public MobileTrackerResponse(Tracker tracker) {
        Hotel hotel = tracker.getHotel();

        this.setTargetID(tracker.getVuforiaId());
        this.setHotelID(hotel.getId());

        hotel.setContents(new ArrayList<>());


        this.setSlideshows(
                hotel.getContents()
                        .stream()
                        .filter(x -> x instanceof SlideshowContent)
                        .filter(x -> ((SlideshowContent) x).getType().equals(SlideshowContent.Type.NORMAL))
                        .map( x -> new SlideshowResponse((SlideshowContent) x) )
                        .collect(Collectors.toList())
        );

    }

    public String getTargetID() {
        return targetID;
    }

    public void setTargetID(String targetID) {
        this.targetID = targetID;
    }

    public long getHotelID() {
        return hotelID;
    }

    public void setHotelID(long hotelID) {
        this.hotelID = hotelID;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWeb() {
        return web;
    }

    public void setWeb(String web) {
        this.web = web;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public boolean isPhoto() {
        return photo;
    }

    public void setPhoto(boolean photo) {
        this.photo = photo;
    }

    public long getSmoothCamFramesPosition() {
        return smoothCamFramesPosition;
    }

    public void setSmoothCamFramesPosition(long smoothCamFramesPosition) {
        this.smoothCamFramesPosition = smoothCamFramesPosition;
    }

    public long getSmoothCamFramesRotation() {
        return smoothCamFramesRotation;
    }

    public void setSmoothCamFramesRotation(long smoothCamFramesRotation) {
        this.smoothCamFramesRotation = smoothCamFramesRotation;
    }

    public List<SlideshowResponse> getSlideshows() {
        return slideshows;
    }

    public void setSlideshows(List<SlideshowResponse> slideshows) {
        this.slideshows = slideshows;
    }

    public static class ContentResponse {

        private long contentID;
        private int weight;
        private String name;

        public ContentResponse(Content content) {
            this.contentID = content.getId();
            this.weight = content.getWeight();
            this.name = content.getName();
        }

        public long getContentID() {
            return contentID;
        }

        public void setContentID(long contentID) {
            this.contentID = contentID;
        }

        public int getWeight() {
            return weight;
        }

        public void setWeight(int weight) {
            this.weight = weight;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }


    public static class SlideshowResponse extends ContentResponse {
        private float[] position = new float[3];
        private float[] rotation = new float[3];
        private float[] scale = new float[3];

        private boolean extendedTracking = false;
        private boolean renderOnTrackingLost = true;

        private List<SlideshowImageResponse> images;

        public SlideshowResponse(SlideshowContent slideshowContent) {
            super(slideshowContent);

            this.position[0] = slideshowContent.getPositionX();
            this.position[1] = slideshowContent.getPositionY();
            this.position[2] = slideshowContent.getPositionZ();

            this.rotation[0] = slideshowContent.getRotationX();
            this.rotation[1] = slideshowContent.getRotationY();
            this.rotation[2] = slideshowContent.getRotationZ();

            this.scale[0] = slideshowContent.getScaleX();
            this.scale[1] = slideshowContent.getScaleY();
            this.scale[2] = slideshowContent.getScaleZ();

            this.images = slideshowContent.getImages().stream().map(SlideshowImageResponse::new).collect(Collectors.toList());

        }

        public float[] getPosition() {
            return position;
        }

        public void setPosition(float[] position) {
            this.position = position;
        }

        public float[] getRotation() {
            return rotation;
        }

        public void setRotation(float[] rotation) {
            this.rotation = rotation;
        }

        public float[] getScale() {
            return scale;
        }

        public void setScale(float[] scale) {
            this.scale = scale;
        }

        public boolean isExtendedTracking() {
            return extendedTracking;
        }

        public void setExtendedTracking(boolean extendedTracking) {
            this.extendedTracking = extendedTracking;
        }

        public boolean isRenderOnTrackingLost() {
            return renderOnTrackingLost;
        }

        public void setRenderOnTrackingLost(boolean renderOnTrackingLost) {
            this.renderOnTrackingLost = renderOnTrackingLost;
        }

        public List<SlideshowImageResponse> getImages() {
            return images;
        }

        public void setImages(List<SlideshowImageResponse> images) {
            this.images = images;
        }
    }

    public static class SlideshowImageResponse {

        private long contentID;
        private String path;
        private float weight;
        private String name = null;

        public SlideshowImageResponse(SlideshowImage slideshowImage) {
            this.contentID = slideshowImage.getId();
            this.path = slideshowImage.getUrl();
            this.weight = slideshowImage.getWeight();
        }

        public long getContentID() {
            return contentID;
        }

        public void setContentID(long contentID) {
            this.contentID = contentID;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public float getWeight() {
            return weight;
        }

        public void setWeight(float weight) {
            this.weight = weight;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }



}
