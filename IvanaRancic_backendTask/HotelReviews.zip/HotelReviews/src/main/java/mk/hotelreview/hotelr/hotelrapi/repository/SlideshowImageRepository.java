package mk.hotelreview.hotelr.hotelrapi.repository;

import mk.hotelreview.hotelr.hotelrapi.entity.content.SlideshowContent;
import mk.hotelreview.hotelr.hotelrapi.entity.content.SlideshowImage;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface SlideshowImageRepository extends JpaRepository<SlideshowImage, Long> {
    Optional<SlideshowImage> findFirstBySlideshowOrderByWeightDesc(SlideshowContent slideshowContent);
    Optional<SlideshowImage> findFirstBySlideshowAndWeight(SlideshowContent slideshowContent, int weight);

}
