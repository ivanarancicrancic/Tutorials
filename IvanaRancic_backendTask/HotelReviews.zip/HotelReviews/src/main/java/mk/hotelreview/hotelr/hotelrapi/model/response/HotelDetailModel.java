package mk.hotelreview.hotelr.hotelrapi.model.response;

import mk.hotelreview.hotelr.hotelrapi.entity.content.Content;
import mk.hotelreview.hotelr.hotelrapi.entity.content.SlideshowContent;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;
import java.util.List;
import java.util.stream.Collectors;

public class HotelDetailModel {

    private long id;
    private String name;
    private String description;
    private List<TrackerModel> tracker;
    private List<ContentModel> contents;
    private List<HotelReviewModel> reviews;
    private boolean temporary;

    public HotelDetailModel() {
    }

    private ContentModel contentToModel(Content content) {
         if(content instanceof SlideshowContent) {
            return new SlideshowContentModel((SlideshowContent) content);
        } else {
            return new ContentModel(content, null);
        }

    }

    public HotelDetailModel(Hotel hotel) {
        this.id = hotel.getId();
        this.name = hotel.getName();
        this.description = hotel.getDescription();

        this.tracker = hotel
                .getTracker()
                .stream()
                .map(TrackerModel::new)
                .collect(Collectors.toList());

//        List<Content> hotelContents = hotel.getContents();
//        this.contents = hotelContents
//                .stream()
//                .map(this::contentToModel)
//                .collect(Collectors.toList());

        this.temporary = hotel.isTemporary();

        this.reviews = hotel
                .getReviews()
                .stream()
                .map(HotelReviewModel::new)
                .collect(Collectors.toList());


    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<TrackerModel> getTracker() {
        return tracker;
    }

    public void setTracker(List<TrackerModel> tracker) {
        this.tracker = tracker;
    }

    public List<ContentModel> getContents() {
        return contents;
    }

    public void setContents(List<ContentModel> contents) {
        this.contents = contents;
    }

    public boolean isTemporary() {
        return temporary;
    }

    public void setTemporary(boolean temporary) {
        this.temporary = temporary;
    }

    public List<HotelReviewModel> getReviews() {
        return reviews;
    }

    public void setReviews(List<HotelReviewModel> reviews) {
        this.reviews = reviews;
    }
}
