package mk.hotelreview.hotelr.hotelrapi.exceptions;

public class NoHotelReviewLikeAvailableException extends Throwable {
}
