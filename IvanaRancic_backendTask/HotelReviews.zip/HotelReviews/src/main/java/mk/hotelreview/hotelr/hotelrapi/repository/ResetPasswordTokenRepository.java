package mk.hotelreview.hotelr.hotelrapi.repository;

import mk.hotelreview.hotelr.hotelrapi.entity.user.ResetPasswordToken;
import mk.hotelreview.hotelr.hotelrapi.entity.user.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface ResetPasswordTokenRepository extends JpaRepository<ResetPasswordToken, Long> {
    Optional<ResetPasswordToken> findByUser(User user);
    Optional<ResetPasswordToken> findByUserAndToken(User user, String tokenValue);
}
