package mk.hotelreview.hotelr.hotelrapi.repository;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;
import mk.hotelreview.hotelr.hotelrapi.entity.review.HotelReview;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface HotelReviewRepository extends JpaRepository<HotelReview, Long> {
    Optional<HotelReview> findFirstByCode(String code);
    Optional<HotelReview> findByHotelName(String name);

}
