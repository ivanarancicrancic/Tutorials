package mk.hotelreview.hotelr.hotelrapi.security;

import mk.hotelreview.hotelr.hotelrapi.entity.user.User;
import mk.hotelreview.hotelr.hotelrapi.service.UserService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class AuthenticationFacade {

    private final UserService userService;

    public AuthenticationFacade(UserService userService) {
        this.userService = userService;
    }

    public mk.hotelreview.hotelr.hotelrapi.entity.user.User getAuthenticatedUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = (String) auth.getPrincipal();
        return userService.getUserByUsername(username);
    }

}
