package mk.hotelreview.hotelr.hotelrapi.exceptions;

public class NoMoneyException extends Throwable {
}
