package mk.hotelreview.hotelr.hotelrapi.controller;

import mk.hotelreview.hotelr.hotelrapi.model.response.CaptchaModel;
import mk.hotelreview.hotelr.hotelrapi.service.CaptchaService;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
public class CaptchaController {

    private final CaptchaService captchaService;

    public CaptchaController(CaptchaService captchaService) {
        this.captchaService = captchaService;
    }

    @RequestMapping(value = {"/captcha", "/captcha/{lastId}"}, method = RequestMethod.POST)
    public CaptchaModel createCaptcha(@PathVariable() Optional<String> lastId) {
        // cleanup already existing captcha when getting request to create a new for provided ID
        lastId.ifPresent(s -> captchaService.deleteCaptcha(s));
        return captchaService.generateCaptcha();
    }

}
