package mk.hotelreview.hotelr.hotelrapi.entity.hotel;

import javax.persistence.*;

@Table
@Entity(name = "contactinfos")
public class ContactInformation {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_contactinfo")
    private long id;

//    @OneToMany(mappedBy = "contact")
//    private List<Hotel> hotels = new ArrayList<>();

    @Column(name="name")
    private String name;

    @Column(name="country")
    private String country;

    @Column(name="homepage")
    private String homepage;

    @Column(name="email")
    private String email;

    @Column(name="address")
    private String address;

    @Column(name="number")
    private String number;

    @Column(name="zip")
    private String zip;

    @Column(name="city")
    private String city;

    // getter & setter

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

//    @JsonIgnore
//    public List<Hotel> getHotels() {
//        return hotels;
//    }
//
//    public void setHotels(List<Hotel> hotels) {
//        this.hotels = hotels;
//    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getHomepage() {
        return homepage;
    }

    public void setHomepage(String homepage) {
        this.homepage = homepage;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }


    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
