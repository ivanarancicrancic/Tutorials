package mk.hotelreview.hotelr.hotelrapi.controller;

import it.ozimov.springboot.mail.service.exception.CannotSendEmailException;
import mk.hotelreview.hotelr.hotelrapi.entity.user.User;
import mk.hotelreview.hotelr.hotelrapi.exceptions.InvalidCaptchaException;
import mk.hotelreview.hotelr.hotelrapi.model.request.CreateAccountModel;
import mk.hotelreview.hotelr.hotelrapi.model.request.ForgotPasswordModel;
import mk.hotelreview.hotelr.hotelrapi.model.request.ForgotPasswordResetModel;
import mk.hotelreview.hotelr.hotelrapi.service.CaptchaService;
import mk.hotelreview.hotelr.hotelrapi.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.NoSuchElementException;

@RestController
public class AccountController {

    private final CaptchaService captchaService;
    private final UserService userService;

    public AccountController(UserService userService, CaptchaService captchaService) {
        this.userService = userService;
        this.captchaService = captchaService;
    }

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public ResponseEntity createAccount(@Valid @RequestBody CreateAccountModel model) {
        boolean approved = captchaService.verifyCaptcha(model.getCaptcha());
        if(approved) {
            userService.create(model);
            return new ResponseEntity(HttpStatus.OK);
        } else {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }

    @RequestMapping(value = "/forgotpw", method = RequestMethod.POST)
    public ResponseEntity forgotPassword(@Valid @RequestBody ForgotPasswordModel model) throws InvalidCaptchaException {
        boolean approved = captchaService.verifyCaptcha(model.getCaptcha());

        if(!approved) {
            throw new InvalidCaptchaException();
        }
        try {
            userService.forgotPassword(model);

        } catch(NoSuchElementException ex){
            return new ResponseEntity(HttpStatus.OK);
        } catch(CannotSendEmailException ex){
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity(HttpStatus.OK);
    }

    @PostMapping("/resetpw")
    public ResponseEntity resetPasswordRequest(@Valid @RequestBody ForgotPasswordResetModel model) {
        try {
            User user = userService.getUserByUsername(model.getEmail());

            boolean check = userService.resetPassword(user, model.getToken(), model.getNewPassword());
            if(!check){
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
            } else {
                return new ResponseEntity<>(HttpStatus.OK);
            }

        } catch(NoSuchElementException ex){
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        } catch(CannotSendEmailException e){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
