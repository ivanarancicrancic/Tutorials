create table uploads
(
  key_upload bigserial    not null
    constraint uploads_pkey
    primary key,
  url        text not null,
  fk_user    bigint       not null
    constraint fk6e7ebgqbpjek4tris85otbf5d
    references users,
  created_at timestamp    not null
);